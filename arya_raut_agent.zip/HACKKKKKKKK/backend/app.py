from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import fitz  # PyMuPDF
import json
import re

app = Flask(__name__)
CORS(app)

# === File Handling ===

def extract_text_from_pdf(pdf_bytes):
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    return "\n".join([page.get_text() for page in doc])

def extract_text_from_txt(txt_bytes):
    return txt_bytes.decode("utf-8")

# === Extract Claim Details ===

def extract_claim_details(text):
    details = {
        "insured_name": "Insured",
        "policy_number": "Unknown",
        "claim_number": "Unknown",
        "amount_paid": "₹[Amount]",
        "date_of_loss": "[Date]",
        "location": "Unknown",
        "third_party": "Third party"
    }

    name_match = re.search(r"insured[:\- ]+(Mr\.|Ms\.|Mrs\.)?\s?([A-Z][a-z]+(?:\s[A-Z][a-z]+)?)", text, re.IGNORECASE)
    policy_match = re.search(r"policy number[:\- ]+([A-Z0-9]+)", text, re.IGNORECASE)
    claim_match = re.search(r"claim number[:\- ]+([A-Z0-9\-]+)", text, re.IGNORECASE)
    amount_match = re.search(r"(₹|Rs\\.?)[\\s]?[\d,]+", text)
    date_match = re.search(r"date of loss[:\- ]+([A-Za-z]+\s\d{1,2},\s\d{4})", text, re.IGNORECASE)
    location_match = re.search(r"location[:\- ]+([A-Za-z\s]+)", text, re.IGNORECASE)
    third_party_match = re.search(r"third[- ]party[:\- ]+(Mr\.|Ms\.|Mrs\.)?\s?([A-Z][a-z]+(?:\s[A-Z][a-z]+)?)", text, re.IGNORECASE)

    if name_match:
        details["insured_name"] = name_match.group(0).split(":")[-1].strip()
    if policy_match:
        details["policy_number"] = policy_match.group(1)
    if claim_match:
        details["claim_number"] = claim_match.group(1)
    if amount_match:
        details["amount_paid"] = amount_match.group(0)
    if date_match:
        details["date_of_loss"] = date_match.group(1)
    if location_match:
        details["location"] = location_match.group(1).strip()
    if third_party_match:
        details["third_party"] = third_party_match.group(0).split(":")[-1].strip()

    return details

# === Dynamic LLaMA3-Like Inference ===

def llama3_infer(prompt):
    claim_text = prompt.split("Claim Text:")[-1].strip().lower()

    third_party_indicators = [
        "rear-end", "hit by", "third party", "another vehicle",
        "not at fault", "liability lies with", "negligence of other driver"
    ]

    own_fault_indicators = [
        "lost control", "speeding", "skidded", "hit pole", "own damage",
        "self-inflicted", "no third party", "insured admitted fault"
    ]

    if any(term in claim_text for term in third_party_indicators):
        return json.dumps({
            "recoverable": True,
            "confidence": 90,
            "explanation": (
                "The claim text shows clear third-party negligence. Recovery is legally justified under subrogation."
            )
        })

    elif any(term in claim_text for term in own_fault_indicators):
        return json.dumps({
            "recoverable": False,
            "confidence": 85,
            "explanation": (
                "The incident was caused by the insured's own fault with no third party involved. Subrogation not applicable."
            )
        })

    else:
        return json.dumps({
            "recoverable": False,
            "confidence": 50,
            "explanation": (
                "The claim lacks clear evidence of third-party fault. Subrogation potential is uncertain."
            )
        })

# === Routes ===

@app.route("/upload", methods=["POST"])
def upload():
    uploaded_file = request.files.get("file")
    if not uploaded_file:
        return jsonify({"error": "No file provided"}), 400

    filename = uploaded_file.filename
    file_bytes = uploaded_file.read()

    if filename.endswith(".pdf"):
        extracted_text = extract_text_from_pdf(file_bytes)
    elif filename.endswith(".txt"):
        extracted_text = extract_text_from_txt(file_bytes)
    else:
        return jsonify({"error": "Unsupported file format"}), 400

    return jsonify({"extracted_text": extracted_text})


@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    claim_text = data.get("text", "")

    prompt = f"""
You are a senior legal advisor for insurance subrogation.

Analyze the following claim text and return:
- recoverable: true/false
- confidence: 0-100
- legal explanation

Claim Text:
{claim_text}
"""

    response = llama3_infer(prompt)
    try:
        result = json.loads(response)
    except:
        result = {
            "recoverable": None,
            "confidence": 0,
            "explanation": "Error analyzing the claim. Try again."
        }

    return jsonify(result)


@app.route("/generate-letter", methods=["POST"])
def generate_letter():
    data = request.get_json()
    claim_text = data.get("text", "")
    details = extract_claim_details(claim_text)

    letter = f"""
XYZ Insurance Co.
Legal Recovery Department
123 Insurance Ave, Mumbai, MH - 400001
Phone: +91-22-12345678 | Email: legal@xyzinsurance.com

Date: [Auto-Generated]

To,
Claims Department
[Third Party Insurer Name]

Subject: Subrogation Demand Letter – Claim Number: {details['claim_number']}

Dear Sir/Madam,

We are writing on behalf of our insured:
- Name: {details['insured_name']}
- Policy Number: {details['policy_number']}
- Claim Number: {details['claim_number']}
- Date of Loss: {details['date_of_loss']}
- Location: {details['location']}
- Third Party Driver: {details['third_party']}

**Incident Summary:**
On the above-mentioned date, our insured’s vehicle was involved in a road accident caused by the third party. Liability lies with the third party based on police findings and eyewitness statements.

**Claim Payment Details:**
- Amount Paid: {details['amount_paid']}
- Mode of Payment: NEFT to insured

**Legal Basis for Subrogation:**
- Clear third-party negligence
- Subrogation rights under Policy {details['policy_number']}
- Supported by evidence: police report, photographs, statements

**We Demand:**
- Reimbursement of {details['amount_paid']} within 15 calendar days of this notice.

Enclosures:
- Police Report
- Repair Invoice
- Proof of Payment

Sincerely,  
Legal Recovery Officer  
XYZ Insurance Co.
"""

    with open("letter_to_insurer.txt", "w", encoding="utf-8") as f:
        f.write(letter.strip())

    return jsonify({"letter": letter})


@app.route("/download-letter", methods=["GET"])
def download_letter():
    try:
        return send_file("letter_to_insurer.txt", as_attachment=True)
    except FileNotFoundError:
        return jsonify({"error": "No letter found. Please generate one first."}), 404


if __name__ == "__main__":
    app.run(debug=True, port=5000)

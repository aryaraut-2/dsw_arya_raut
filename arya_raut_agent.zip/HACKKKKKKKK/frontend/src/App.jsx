
import React, { useState } from "react";
import axios from "axios";
import "./styles.css";

export default function App() {
  const [file, setFile] = useState(null);
  const [text, setText] = useState("");
  const [analysis, setAnalysis] = useState(null);
  const [letter, setLetter] = useState("");
  const [loading, setLoading] = useState(false);

  const uploadFile = async () => {
    if (!file) return alert("Please select a file");
    setLoading(true);
    const formData = new FormData();
    formData.append("file", file);
    try {
      const res = await axios.post("http://localhost:5000/upload", formData);
      setText(res.data.extracted_text);
      setAnalysis(null);
      setLetter("");
    } catch {
      alert("Upload failed");
    }
    setLoading(false);
  };

  const analyze = async () => {
    setLoading(true);
    try {
      const res = await axios.post("http://localhost:5000/analyze", { text });
      setAnalysis(res.data);
    } catch {
      alert("Analysis failed");
    }
    setLoading(false);
  };

  const generate = async () => {
    setLoading(true);
    try {
      const res = await axios.post("http://localhost:5000/generate-letter", { text });
      setLetter(res.data.letter);
    } catch {
      alert("Generation failed");
    }
    setLoading(false);
  };

  const getConfidenceColor = (score) => {
    if (score >= 80) return "green";
    if (score >= 50) return "orange";
    return "red";
  };

  return (
    <div className="container">
      <div className="card">
        <div className="header">
          <img src="/bot.png" alt="Bot" className="bot-icon" />
          <h1>Subrogation Recovery Agent</h1>
        </div>
        <div className="upload-row">
          <input
            className="input-box"
            type="text"
            value={file ? file.name : ""}
            placeholder="Upload your claim document..."
            disabled
          />
          <input
            type="file"
            accept=".pdf,.txt"
            style={{ display: "none" }}
            id="file-upload"
            onChange={(e) => setFile(e.target.files[0])}
          />
          <label htmlFor="file-upload" className="upload-btn">Upload</label>
          <button onClick={uploadFile} className="analyze-btn">Extract</button>
        </div>

        {text && (
          <div className="text-section">
            <h3>Extracted Text</h3>
            <div className="box">{text}</div>
            <button onClick={analyze} className="analyze-btn">Analyze</button>
          </div>
        )}

        {analysis && (
          <div className="text-section">
            <h3>Analysis</h3>
            <div className="box">
              <p><b>Recoverable:</b> {analysis.recoverable ? "Yes ✅" : "No ❌"}</p>
              <p>
                <b>Confidence:</b> <span style={{ color: getConfidenceColor(analysis.confidence) }}>{analysis.confidence}%</span>
              </p>
              <p><b>Explanation:</b> {analysis.explanation}</p>
            </div>
            <button onClick={generate} className="generate-btn">Generate Demand Letter</button>
          </div>
        )}

        {letter && (
  <div className="text-section">
    <h3>Demand Letter</h3>
    <div className="box">{letter}</div>
    <button
      onClick={() => window.open("http://localhost:5000/download-letter", "_blank")}
      className="generate-btn"
      style={{ marginTop: "10px" }}
    >
      📥 Download Letter
    </button>
  </div>
)}


        {loading && <p className="loading">⏳ Please wait...</p>}
      </div>
    </div>
  );
}
